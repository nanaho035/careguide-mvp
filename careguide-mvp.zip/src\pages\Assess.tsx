import { useState } from 'react';
import { API } from '../api';

export default function Assess() {
  const [ageBand, setAgeBand] = useState<'65+'|'50-64'|'<50'>('65+');
  const [economy, setEconomy] = useState<'general'|'mid-low'|'low'>('general');
  const [hasForeignCaregiver, setHasForeignCaregiver] = useState(false);
  const [adlCount, setAdlCount] = useState(0);
  const [recentHospitalization, setRecentHospitalization] = useState(false);

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string|null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError(null); setResult(null);
    try {
      const r = await API.assess({ ageBand, economy, hasForeignCaregiver, adlCount, recentHospitalization });
      setResult(r);
    } catch (err:any) { setError(err.message ?? 'Request failed'); }
    finally { setLoading(false); }
  }

  return (
    <div style={{maxWidth:560, margin:'24px auto', padding:16}}>
      <h2>資格快篩（長照 2.0）</h2>
      <form onSubmit={onSubmit} style={{display:'grid', gap:12}}>
        <label>年齡區間：
          <select value={ageBand} onChange={e=>setAgeBand(e.target.value as any)}>
            <option value="65+">65+</option>
            <option value="50-64">50–64</option>
            <option value="<50">&lt;50</option>
          </select>
        </label>
        <label>經濟身分：
          <select value={economy} onChange={e=>setEconomy(e.target.value as any)}>
            <option value="general">一般</option>
            <option value="mid-low">中低收</option>
            <option value="low">低收</option>
          </select>
        </label>
        <label>是否僱用外籍看護：
          <input type="checkbox" checked={hasForeignCaregiver} onChange={e=>setHasForeignCaregiver(e.target.checked)} />
        </label>
        <label>ADL 需協助項目數（0–5）：
          <input type="number" min={0} max={5} value={adlCount} onChange={e=>setAdlCount(Number(e.target.value))}/>
        </label>
        <label>最近是否出院返家：
          <input type="checkbox" checked={recentHospitalization} onChange={e=>setRecentHospitalization(e.target.checked)} />
        </label>
        <button disabled={loading}>{loading ? '查詢中…' : '送出快篩'}</button>
      </form>

      <div style={{marginTop:16}}>
        {error && <pre style={{color:'crimson'}}>{error}</pre>}
        {result && (
          <div style={{border:'1px solid #ddd', padding:12, borderRadius:8}}>
            <div>是否符合：<b>{result.eligible ? '可能符合' : '暫不符合'}</b></div>
            {result.levelRange && <div>推估等級區間：<b>{result.levelRange}</b></div>}
            {result.nextSteps && <div>建議下一步：<ul>{result.nextSteps.map((s:string)=><li key={s}>{s}</li>)}</ul></div>}
            <small>ruleset: {result.ruleset}</small>
          </div>
        )}
      </div>
    </div>
  );
}