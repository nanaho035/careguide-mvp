import React, { useState } from 'react';
import EligibilityForm from './components/assess/EligibilityForm';
import LocalePage from './components/locale/LocalePage';
import CopayEstimator from './components/copay/CopayEstimator';
import ProvidersPage from './components/providers/ProvidersPage';
import FAQPage from './components/faq/FAQPage';

type View = 'assess' | 'locale' | 'copay' | 'directory' | 'faq';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>('assess');

  const navItems: { key: View; label: string }[] = [
    { key: 'assess', label: '資格快篩' },
    { key: 'locale', label: '縣市流程' },
    { key: 'copay', label: '自付額試算' },
    { key: 'directory', label: '特約名錄' },
    { key: 'faq', label: '常見問題' },
  ];

  const renderView = () => {
    switch (activeView) {
      case 'assess':
        return <EligibilityForm />;
      case 'locale':
        return <LocalePage />;
      case 'copay':
        return <CopayEstimator />;
      case 'directory':
        return <ProvidersPage />;
      case 'faq':
        return <FAQPage />;
      default:
        return <EligibilityForm />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-teal-700">長照2.0 小幫手</h1>
          <p className="text-slate-600">申請說明與自付額試算 (MVP)</p>
        </div>
        <nav className="bg-teal-600">
          <div className="container mx-auto flex flex-wrap">
            {navItems.map((item) => (
              <button
                key={item.key}
                onClick={() => setActiveView(item.key)}
                className={`flex-grow basis-1/3 md:flex-1 py-3 px-2 text-base font-semibold transition-colors duration-200 min-h-[44px] ${
                  activeView === item.key
                    ? 'bg-white text-teal-700'
                    : 'bg-teal-600 text-white hover:bg-teal-500'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </nav>
      </header>

      <main className="container mx-auto p-4 md:p-6">
        {renderView()}
      </main>

      <footer className="text-center py-4 text-xs text-slate-500">
        <p>此為 MVP 版本，所有資訊僅供參考，請以政府官方公告為準。</p>
      </footer>
    </div>
  );
};

export default App;
