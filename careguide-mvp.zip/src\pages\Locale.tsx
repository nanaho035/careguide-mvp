import { useEffect, useMemo, useState } from "react";
import { DEFAULT_FLOW, FLOWS, CityFlow } from "../data/localeTemplates";

type CheckMap = Record<string, boolean>;
const KEY = (cityId:string) => `careguide.flow.${cityId}.v1`;

function loadChecks(cityId:string): CheckMap {
  try { return JSON.parse(localStorage.getItem(KEY(cityId)) || "{}"); }
  catch { return {}; }
}
function saveChecks(cityId:string, map:CheckMap) {
  localStorage.setItem(KEY(cityId), JSON.stringify(map));
}

export default function Locale() {
  const [cityId, setCityId] = useState<string>(FLOWS[0]?.id || DEFAULT_FLOW.id);
  const flow: CityFlow = useMemo(() => FLOWS.find(f=>f.id===cityId) || DEFAULT_FLOW, [cityId]);
  const [checks, setChecks] = useState<CheckMap>(() => loadChecks(cityId));

  useEffect(() => { setChecks(loadChecks(cityId)); }, [cityId]);
  useEffect(() => { saveChecks(cityId, checks); }, [cityId, checks]);

  const doneCount = Object.values(checks).filter(Boolean).length;
  const pct = Math.round((doneCount / (flow.steps.length || 1)) * 100);

  function toggle(id:string) {
    setChecks(prev => ({ ...prev, [id]: !prev[id] }));
  }
  function reset() {
    if (confirm("清除本縣市的勾選進度？")) setChecks({});
  }
  function printPage() { window.print(); }

  return (
    <div style={{maxWidth: 920, margin: "24px auto", padding: 16}}>
      <h2>縣市流程</h2>

      <div style={{display:"flex", gap: 12, alignItems:"center", marginBottom: 12}}>
        <label>選擇縣市：
          <select value={cityId} onChange={e=>setCityId(e.target.value)} style={{marginLeft:8}}>
            {FLOWS.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
            <option value={DEFAULT_FLOW.id}>{DEFAULT_FLOW.name}</option>
          </select>
        </label>
        <div style={{marginLeft:"auto"}}>完成度：<b>{pct}%</b></div>
        <button onClick={reset}>重置進度</button>
        <button onClick={printPage}>列印</button>
      </div>

      {flow.hotline && <p>市話/專線：<b>{flow.hotline}</b></p>}
      {flow.notes && flow.notes.length > 0 && (
        <ul style={{color:"#555"}}>
          {flow.notes.map(n => <li key={n}>{n}</li>)}
        </ul>
      )}

      <ol style={{display:"grid", gap:8, paddingLeft:18}}>
        {flow.steps.map(s => (
          <li key={s.id} style={{border:"1px solid #e6e6e6", borderRadius:8, padding:12, display:"flex", alignItems:"center", gap:12}}>
            <input type="checkbox" checked={!!checks[s.id]} onChange={()=>toggle(s.id)} />
            <div style={{flex:1}}>
              <div style={{fontWeight:600}}>{s.label}</div>
              <div style={{fontSize:12, color:"#666"}}>
                {s.doc && <span>需備文件：{s.doc}　</span>}
                {s.link && <a href={s.link} target="_blank">官方說明</a>}
              </div>
            </div>
          </li>
        ))}
      </ol>

      <div style={{marginTop:16, fontSize:12, color:"#666"}}>
        小提醒：進度僅存於此裝置的瀏覽器（localStorage），清除瀏覽資料將會遺失。
      </div>
    </div>
  );
}

