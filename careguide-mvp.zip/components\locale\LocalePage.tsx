
import React, { useState, useEffect } from 'react';
import { localeData } from '../../data/localeTemplates';
import type { LocaleData } from '../../types';

const LocalePage: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<string>(localeData[0].city);
  const [currentData, setCurrentData] = useState<LocaleData>(localeData[0]);
  const [todos, setTodos] = useState<string[]>([]);
  
  useEffect(() => {
    const storedTodos = localStorage.getItem('ltcTodos');
    if (storedTodos) {
      setTodos(JSON.parse(storedTodos));
    }
  }, []);

  useEffect(() => {
    const data = localeData.find(d => d.city === selectedCity);
    if (data) {
      setCurrentData(data);
      // TODO: Integrate with a real analytics service
      console.log('analytics', { event: 'locale_view', payload: { city: selectedCity } });
    }
  }, [selectedCity]);
  
  const addTodo = (item: string) => {
    if (!todos.includes(item)) {
        const newTodos = [...todos, item];
        setTodos(newTodos);
        localStorage.setItem('ltcTodos', JSON.stringify(newTodos));
    }
  };

  const removeTodo = (itemToRemove: string) => {
    const newTodos = todos.filter(item => item !== itemToRemove);
    setTodos(newTodos);
    localStorage.setItem('ltcTodos', JSON.stringify(newTodos));
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <label htmlFor="city-select" className="block text-lg font-bold mb-2 text-slate-700">選擇您所在的縣市：</label>
        <select
          id="city-select"
          value={selectedCity}
          onChange={(e) => setSelectedCity(e.target.value)}
          className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500"
        >
          {localeData.map(d => <option key={d.city} value={d.city}>{d.city}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
            {/* Process Steps */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold mb-4 text-teal-700">申請流程</h2>
                <ol className="relative border-l-4 border-teal-200">
                    {currentData.processSteps.map((step, index) => (
                        <li key={index} className="mb-10 ml-6">
                            <span className="absolute flex items-center justify-center w-8 h-8 bg-teal-200 rounded-full -left-4 ring-4 ring-white">
                                <span className="font-bold text-teal-800">{index + 1}</span>
                            </span>
                            <h3 className="text-xl font-semibold text-slate-900">{step.title}</h3>
                            <p className="text-base text-slate-600">{step.description}</p>
                        </li>
                    ))}
                </ol>
            </div>
            
            {/* Document Checklist */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold mb-4 text-teal-700">應備文件清單</h2>
                <ul className="space-y-3">
                    {currentData.docChecklist.map((doc, index) => (
                        <li key={index} className="flex justify-between items-center p-3 bg-slate-50 rounded-md">
                            <span className="text-lg text-slate-800">{doc}</span>
                            <button onClick={() => addTodo(doc)} className="min-h-[44px] bg-teal-500 text-white text-sm font-bold py-2 px-4 rounded-lg hover:bg-teal-600 transition-colors">
                            加入待辦
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
        
        <div className="lg:col-span-1 space-y-6">
            {/* My Todos */}
            {todos.length > 0 && (
                <div className="bg-amber-50 p-6 rounded-lg shadow-lg">
                    <h3 className="text-xl font-bold mb-3 text-amber-800">我的待辦事項</h3>
                    <ul className="space-y-2">
                        {todos.map((todo, index) => (
                            <li key={index} className="flex justify-between items-center text-slate-700">
                                <span>{todo}</span>
                                <button onClick={() => removeTodo(todo)} className="text-red-500 hover:text-red-700 text-sm font-bold">移除</button>
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {/* Contacts */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-teal-700">聯絡資訊</h3>
                {currentData.contacts.map((contact, index) => (
                    <div key={index} className="mb-4 border-b pb-4 last:border-b-0 last:pb-0">
                        <p className="font-semibold text-lg">{contact.name}</p>
                        <p className="text-slate-600">電話：<a href={`tel:${contact.phone}`} className="text-blue-600 hover:underline">{contact.phone}</a></p>
                        <p className="text-slate-600">網址：<a href={contact.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">點擊前往</a></p>
                    </div>
                ))}
            </div>

            {/* Notes */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-teal-700">注意事項</h3>
                <p className="text-slate-600">{currentData.avgWaitNotes}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default LocalePage;
