import React from 'react';

const Disclaimer: React.FC = () => {
  return (
    <div className="p-4 bg-amber-100 border-l-4 border-amber-500 text-amber-800 rounded-r-lg" role="alert">
      <h3 className="font-bold text-lg">【重要提醒】</h3>
      <p className="mt-1 text-base">
        此為模擬試算工具，所有資訊、規則與計算結果僅供參考，不具任何法律效力。最終資格、額度與自付金額，均須以您所在縣市「長期照顧管理中心」的正式評估與核定為準。在做出任何決定前，請務必諮詢官方管道或專業人員。
      </p>
    </div>
  );
};

export default Disclaimer;
