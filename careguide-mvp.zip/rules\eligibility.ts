
import type { EligibilityAnswers, EligibilityResult } from '../types';

// TODO: This is a simplified simulation and does not represent official government criteria.
// The rules are for MVP demonstration purposes only.

export const calculateEligibility = (answers: EligibilityAnswers): EligibilityResult => {
  const { ageRange, hasForeignCaregiver, adlDifficulties, isRecentHospitalization } = answers;
  
  const reasons: string[] = [];
  let eligible = false;
  let levelRange: "L2–L4" | null = null;
  
  const isAgeEligible = ageRange !== '以上皆非';
  if (isAgeEligible) {
    reasons.push(`年齡/身份 (${ageRange}) 符合基本申請條件。`);
  } else {
    reasons.push(`年齡/身份 (${ageRange}) 可能不符合基本申請條件。`);
  }

  const hasFunctionalDecline = adlDifficulties.length > 0;
  if (hasFunctionalDecline) {
      reasons.push(`日常生活 (${adlDifficulties.join(', ')}) 需要他人協助，顯示有長照需求。`);
  } else {
      reasons.push('日常生活可自理，可能無立即長照需求。');
  }

  const isCaregiverEligible = hasForeignCaregiver === '否';
  if (!isCaregiverEligible) {
    reasons.push('家中已聘有外籍看護，部分長照服務（如居家服務）將無法申請，但仍可申請喘息服務等資源。');
  } else {
    reasons.push('家中未聘有外籍看護，可申請各項長照服務。');
  }

  if (isRecentHospitalization === '是') {
      reasons.push('近期曾住院，可考慮申請「出院準備銜接長照服務」。');
  }

  // --- Final Decision Logic ---
  if (isAgeEligible && hasFunctionalDecline && isCaregiverEligible) {
    eligible = true;
    levelRange = "L2–L4"; // Simplified mapping
    reasons.unshift('綜合評估：您很可能符合長照2.0服務資格。');
  } else if (isAgeEligible && hasFunctionalDecline && !isCaregiverEligible) {
    eligible = false; // Technically can apply for some services, but simplify for MVP
    reasons.unshift('綜合評估：因已聘有外籍看護，多數照顧服務無法申請，但仍有其他資源可利用。');
  } else {
    eligible = false;
    reasons.unshift('綜合評估：根據您的回答，您可能暫不符合長照2.0服務資格。');
  }

  const nextSteps = eligible
    ? ['立即撥打 1966 長照服務專線，將有專人為您服務。', '或聯繫您所在縣市的「長期照顧管理中心」。', '準備申請人身分證，專員將與您約定訪視評估時間。']
    : ['若情況有變或有疑問，仍可撥打 1966 專線諮詢。', '探索其他社區資源，如里辦公室、社區關懷據點。'];

  return { eligible, levelRange, nextSteps, reasons };
};
