
import type { CopayInputs, CopayResult } from '../types';

// TODO: All values are for MVP demonstration and are not official government rates.
const RULESET = {
    PAYMENT_CAPS: { // 每月給付額度上限
        'L2': 10020,
        'L3': 15460,
        'L4': 18580,
        'L5': 24100,
        'L6': 28070,
        'L7': 32090,
        'L8': 36180,
    },
    COPAY_PERCENTAGES: { // 部分負擔比例
        'general': 0.16,
        'middle_low': 0.05,
        'low': 0.00,
    },
    SERVICE_COSTS: { // 服務單價 (假設值)
        homeCareHour: 350,
        dayCareDay: 1300,
        respiteDay: 2310,
        ruralTransportFee: 2000, // 假設的每月偏鄉交通補助，此處簡化為固定費用
    }
};

export const calculateCopay = (inputs: CopayInputs): CopayResult => {
    const { level, incomeStatus, services, isRural } = inputs;

    const paymentCap = RULESET.PAYMENT_CAPS[level as keyof typeof RULESET.PAYMENT_CAPS];
    const copayRate = RULESET.COPAY_PERCENTAGES[incomeStatus];
    
    const homeCareCost = services.homeCareHours * RULESET.SERVICE_COSTS.homeCareHour;
    const dayCareCost = services.dayCareDays * RULESET.SERVICE_COSTS.dayCareDay;
    // 喘息服務額度與一般服務分開計算，這裡為MVP簡化，將其費用直接計入
    const respiteCost = services.respiteDays * RULESET.SERVICE_COSTS.respiteDay;

    const totalServiceCost = homeCareCost + dayCareCost + respiteCost;

    const coveredAmount = Math.min(totalServiceCost, paymentCap);
    const costOverCap = Math.max(0, totalServiceCost - paymentCap);

    const copayment = coveredAmount * copayRate;

    const ruralFee = isRural ? (RULESET.SERVICE_COSTS.ruralTransportFee * (1 - copayRate)) : 0; // 交通費也需部分負擔

    const totalUserPayment = copayment + costOverCap + ruralFee;

    const breakdown = [
        { service: '照顧及專業服務 (部分負擔)', amount: Math.round(copayment) },
        { service: '超出給付額度 (全額自費)', amount: Math.round(costOverCap) },
        { service: '交通接送 (部分負擔)', amount: Math.round(ruralFee) }
    ];

    // For MVP, provide a simple range around the calculated value
    const min = Math.round(totalUserPayment);
    const max = Math.round(totalUserPayment * 1.15); // Add 15% for potential variations

    return { min, max, breakdown };
};
