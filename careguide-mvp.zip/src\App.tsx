import { useState } from 'react';
import { API } from './api';
import Assess from './pages/Assess';
import Copay from './pages/Copay';
import Locale from './pages/Locale';

type Tab = 'home'|'assess'|'copay'|'locale';

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const [apiStatus, setApiStatus] = useState<any>(null);

  async function testApi() {
    const r = await API.status();
    setApiStatus(r);
  }

  return (
    <div style={{maxWidth:960, margin:'0 auto', padding:24}}>
      <h1>CareGuide</h1>
      <nav style={{display:'flex', gap:8, marginBottom:16}}>
        <button onClick={()=>setTab('home')}>Home</button>
        <button onClick={()=>setTab('assess')}>資格快篩</button>
        <button onClick={()=>setTab('copay')}>自付額估算</button>
        <button onClick={()=>setTab('locale')}>縣市流程</button>
        <button onClick={testApi} style={{marginLeft:'auto'}}>Test API</button>
      </nav>

      {tab === 'home' && (
        <div>
          <p>這是首頁。點上方分頁開始測試。</p>
          <h3>API Result:</h3>
          <pre>{apiStatus ? JSON.stringify(apiStatus, null, 2) : '尚未測試'}</pre>
        </div>
      )}
      {tab === 'assess' && <Assess />}
      {tab === 'copay' && <Copay />}
      {tab === 'locale' && <Locale />}
    </div>
  );
}