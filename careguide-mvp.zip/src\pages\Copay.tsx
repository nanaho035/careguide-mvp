import { useState } from 'react';
import { API } from '../api';

export default function Copay() {
  const [level, setLevel] = useState<'L2'|'L3'|'L4'|'L5'|'L6'|'L7'|'L8'>('L3');
  const [economy, setEconomy] = useState<'general'|'mid-low'|'low'>('general');
  const [home, setHome] = useState(0);
  const [daycare, setDaycare] = useState(0);
  const [respite, setRespite] = useState(0);

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string|null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError(null); setResult(null);
    try {
      const services = [
        { code:'home' as const, freqPerWeek: home },
        { code:'daycare' as const, freqPerWeek: daycare },
        { code:'respite' as const, freqPerWeek: respite },
      ].filter(s=>s.freqPerWeek>0);
      const r = await API.copay({ level, economy, services });
      setResult(r);
    } catch (err:any) { setError(err.message ?? 'Request failed'); }
    finally { setLoading(false); }
  }

  return (
    <div style={{maxWidth:560, margin:'24px auto', padding:16}}>
      <h2>自付額估算</h2>
      <form onSubmit={onSubmit} style={{display:'grid', gap:12}}>
        <label>核定等級：
          <select value={level} onChange={e=>setLevel(e.target.value as any)}>
            {['L2','L3','L4','L5','L6','L7','L8'].map(l=><option key={l} value={l}>{l}</option>)}
          </select>
        </label>
        <label>經濟身分：
          <select value={economy} onChange={e=>setEconomy(e.target.value as any)}>
            <option value="general">一般</option>
            <option value="mid-low">中低收</option>
            <option value="low">低收</option>
          </select>
        </label>
        <fieldset style={{border:'1px solid #ddd', padding:12}}>
          <legend>每週服務頻率</legend>
          <label>到宅服務（home）：<input type="number" min={0} max={7} value={home} onChange={e=>setHome(Number(e.target.value))}/></label>
          <label>日照（daycare）：<input type="number" min={0} max={7} value={daycare} onChange={e=>setDaycare(Number(e.target.value))}/></label>
          <label>喘息（respite）：<input type="number" min={0} max={7} value={respite} onChange={e=>setRespite(Number(e.target.value))}/></label>
        </fieldset>
        <button disabled={loading}>{loading ? '計算中…' : '估算自付額'}</button>
      </form>

      <div style={{marginTop:16}}>
        {error && <pre style={{color:'crimson'}}>{error}</pre>}
        {result && (
          <div style={{border:'1px solid #ddd', padding:12, borderRadius:8}}>
            <div>預估自付額區間：<b>${result.min} ~ ${result.max}</b></div>
            {result.assumptions && <small>假設：{result.assumptions.join('；')}</small>}
            <div><small>ruleset: {result.ruleset}</small></div>
          </div>
        )}
      </div>
    </div>
  );
}