import React, { useState, useMemo, useEffect } from 'react';
import type { Provider } from '../../types';

const ProvidersPage: React.FC = () => {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [filters, setFilters] = useState({ city: '', service: '' });
  const [sortBy, setSortBy] = useState('rating_desc');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null);

  useEffect(() => {
    // 使用 fetch 載入 JSON 資料，路徑相對於 index.html
    fetch('./data/providers.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data: Provider[]) => setProviders(data))
      .catch(error => console.error("Error loading providers data:", error));
  }, []); // 空依賴陣列，確保只在元件掛載時執行一次

  const allCities = useMemo(() => [...new Set(providers.map(p => p.city))], [providers]);
  const allServices = useMemo(() => [...new Set(providers.flatMap(p => p.services))], [providers]);
  
  const handleFilterChange = (type: 'city' | 'service', value: string) => {
    setFilters(prev => ({ ...prev, [type]: value }));
  };

  const clearFilters = () => {
    setFilters({ city: '', service: '' });
  };
  
  const filteredAndSortedProviders = useMemo(() => {
    let result = [...providers];
    
    if (filters.city) {
      result = result.filter(p => p.city === filters.city);
    }
    if (filters.service) {
      result = result.filter(p => p.services.includes(filters.service as any));
    }
    
    if (sortBy === 'rating_desc') {
      result.sort((a, b) => b.rating - a.rating);
    }
    
    return result;
  }, [providers, filters, sortBy]);

  const openModal = (provider: Provider) => {
    setSelectedProvider(provider);
    setIsModalOpen(true);
  };
  
  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedProvider(null);
  };

  const handleLeadSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const leadData = {
        providerId: selectedProvider?.id,
        providerName: selectedProvider?.name,
        leadName: formData.get('name'),
        leadPhone: formData.get('phone'),
    };
    // TODO: Integrate with a real analytics service
    console.log('analytics', { event: 'lead_submit', payload: leadData });
    alert('您的諮詢需求已送出，將有專人與您聯繫！');
    closeModal();
  };

  return (
    <div className="space-y-6">
      <div className="bg-rose-100 border-l-4 border-rose-500 text-rose-800 p-4 rounded-r-lg shadow-md" role="alert">
        <p className="font-bold text-lg">注意：此為商業合作內容，非官方名錄</p>
        <p>以下列表僅為範例，資訊的即時性與正確性請以各單位官方公告為準。</p>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-lg space-y-4 md:space-y-0 md:flex md:items-center md:justify-between">
        <div className="flex flex-wrap gap-4 items-center">
          <select value={filters.city} onChange={e => handleFilterChange('city', e.target.value)} className="min-h-[44px] p-2 text-base border-2 border-slate-300 rounded-lg">
            <option value="">所有縣市</option>
            {allCities.map(city => <option key={city} value={city}>{city}</option>)}
          </select>
          <div className="flex flex-wrap gap-2">
            {allServices.map(service => (
              <button key={service} onClick={() => handleFilterChange('service', filters.service === service ? '' : service)} className={`min-h-[44px] px-4 py-2 text-base font-semibold rounded-full transition-colors ${filters.service === service ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}>
                {service}
              </button>
            ))}
          </div>
          <button onClick={clearFilters} className="text-blue-600 hover:underline text-base">清除篩選</button>
        </div>
        <div className="flex items-center gap-2">
            <label htmlFor="sort-by" className="text-base font-bold">排序：</label>
            <select id="sort-by" value={sortBy} onChange={e => setSortBy(e.target.value)} className="min-h-[44px] p-2 text-base border-2 border-slate-300 rounded-lg">
                <option value="rating_desc">評分由高至低</option>
            </select>
        </div>
      </div>

      {/* Providers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAndSortedProviders.length > 0 ? (
          filteredAndSortedProviders.map(provider => (
            <div key={provider.id} className="bg-white rounded-lg shadow-lg p-6 flex flex-col justify-between border-t-4 border-teal-500">
              <div>
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-slate-900">{provider.name}</h3>
                  <div className="bg-amber-400 text-white text-lg font-bold px-3 py-1 rounded-full flex items-center gap-1">
                    <span>⭐</span><span>{provider.rating}</span>
                  </div>
                </div>
                <p className="text-sm text-slate-500 bg-slate-100 inline-block px-2 py-1 rounded">✅ {provider.approvalId}</p>
                <div className="my-3 flex flex-wrap gap-2">
                  {provider.services.map(s => <span key={s} className="bg-teal-100 text-teal-800 text-sm font-semibold px-3 py-1 rounded-full">{s}</span>)}
                </div>
                <p className="text-base text-slate-600 mt-2">📞 <a href={`tel:${provider.phone}`} className="text-blue-600 hover:underline">{provider.phone}</a></p>
                <p className="text-base text-slate-600">📍 {provider.address}</p>
              </div>
              <button onClick={() => openModal(provider)} className="w-full min-h-[44px] mt-4 bg-teal-600 text-white font-bold py-3 px-6 text-lg rounded-lg hover:bg-teal-700 transition-colors">
                先問再約
              </button>
            </div>
          ))
        ) : (
          <div className="md:col-span-2 lg:col-span-3 text-center py-10 text-slate-500">
            <p>正在載入特約單位資料...</p>
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && selectedProvider && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-lg shadow-xl p-8 max-w-lg w-full relative">
            <button onClick={closeModal} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 text-3xl">&times;</button>
            <h2 className="text-2xl font-bold mb-1 text-teal-700">諮詢服務</h2>
            <p className="text-lg text-slate-600 mb-6">向 <span className="font-bold">{selectedProvider.name}</span> 預約諮詢</p>
            <form onSubmit={handleLeadSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-lg font-bold text-slate-700 mb-1">您的姓名</label>
                <input type="text" id="name" name="name" required className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg"/>
              </div>
              <div>
                <label htmlFor="phone" className="block text-lg font-bold text-slate-700 mb-1">聯絡電話</label>
                <input type="tel" id="phone" name="phone" required className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg"/>
              </div>
              <button type="submit" className="w-full min-h-[44px] bg-green-600 text-white font-bold py-3 px-6 text-lg rounded-lg hover:bg-green-700 transition-colors">確認送出</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProvidersPage;