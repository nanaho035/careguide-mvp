export interface EligibilityAnswers {
  ageRange: string;
  incomeStatus: string;
  hasForeignCaregiver: string;
  adlDifficulties: string[];
  isRecentHospitalization: string;
}

export interface EligibilityResult {
  eligible: boolean;
  levelRange: "L2–L4" | null;
  nextSteps: string[];
  reasons: string[];
}

export interface LocaleData {
  city: string;
  processSteps: { title: string; description: string }[];
  contacts: { name: string; phone: string; website: string }[];
  docChecklist: string[];
  avgWaitNotes: string;
}

export interface CopayInputs {
    level: string;
    incomeStatus: 'general' | 'middle_low' | 'low';
    services: {
        homeCareHours: number;
        dayCareDays: number;
        respiteDays: number;
    };
    isRural: boolean;
}

export interface CopayResult {
    min: number;
    max: number;
    breakdown: { service: string; amount: number }[];
}

export interface Provider {
  id: number;
  name: string;
  city: string;
  services: ('居家服務' | '日間照顧' | '喘息服務')[];
  phone: string;
  address: string;
  rating: number;
  approvalId: string;
}
