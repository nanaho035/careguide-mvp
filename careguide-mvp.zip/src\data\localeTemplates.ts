export type Step = {
  id: string;
  label: string;
  link?: string;      // 官方連結（可選）
  doc?: string;       // 需要文件（可選）
};
export type CityFlow = {
  id: string;
  name: string;
  hotline?: string;
  notes?: string[];
  steps: Step[];
};

export const FLOWS: CityFlow[] = [
  {
    id: "taipei",
    name: "臺北市",
    hotline: "1999#1801",
    notes: ["實際流程以當地照管中心公告為準。"],
    steps: [
      { id:"call-1966", label:"撥打 1966 / 1999#1801 進行長照諮詢" },
      { id:"prepare-docs", label:"備妥文件：身分證、戶口名簿、印章、診斷書等" },
      { id:"assign-care", label:"由照管中心指派照專聯繫與開案評估" },
      { id:"home-visit", label:"居家訪視與評估（ADL/IADL）" },
      { id:"level-decide", label:"核定失能等級與給付額度" },
      { id:"service-plan", label:"擬定照顧與服務計畫" },
      { id:"service-start", label:"媒合單位並開始服務" }
    ],
  },
  {
    id: "newtaipei",
    name: "新北市",
    hotline: "1999#1827",
    steps: [
      { id:"call-1966", label:"撥打 1966 / 1999#1827 諮詢並留下聯絡" },
      { id:"prepare-docs", label:"準備身分/戶籍/診斷書等文件" },
      { id:"home-visit", label:"由照管中心安排居家評估" },
      { id:"level-decide", label:"核定等級與額度、說明自付額" },
      { id:"service-start", label:"啟用居家/日照/喘息等服務" }
    ],
  },
  {
    id: "taoyuan",
    name: "桃園市",
    hotline: "03-3322101",
    steps: [
      { id:"call-1966", label:"撥打 1966 或桃園市長照專線" },
      { id:"prepare-docs", label:"備妥證件與醫療相關文件" },
      { id:"home-visit", label:"到宅評估" },
      { id:"level-decide", label:"核定與告知" },
      { id:"service-start", label:"媒合單位與執行" }
    ],
  },
  {
    id: "taichung",
    name: "臺中市",
    hotline: "1999#1100",
    steps: [
      { id:"call-1966", label:"撥打 1966 / 1999#1100 諮詢" },
      { id:"home-visit", label:"居家評估" },
      { id:"level-decide", label:"核定等級與額度" },
      { id:"service-plan", label:"擬定服務計畫" },
      { id:"service-start", label:"開始服務" }
    ],
  },
  {
    id: "kaohsiung",
    name: "高雄市",
    hotline: "07-337-9111",
    steps: [
      { id:"call-1966", label:"撥打 1966 或高雄市長照專線" },
      { id:"prepare-docs", label:"準備文件與聯絡方式" },
      { id:"home-visit", label:"居家評估" },
      { id:"level-decide", label:"核定等級/額度與自付額" },
      { id:"service-start", label:"媒合單位與啟用" }
    ],
  },
];

export const DEFAULT_FLOW: CityFlow = {
  id: "generic",
  name: "一般流程",
  steps: [
    { id:"call-1966", label:"撥打 1966 申請長照諮詢" },
    { id:"prepare-docs", label:"準備身分證/戶口名簿/診斷書等" },
    { id:"home-visit", label:"照專到宅評估（ADL/IADL）" },
    { id:"level-decide", label:"核定等級與額度，說明自付額" },
    { id:"service-plan", label:"擬定服務計畫" },
    { id:"service-start", label:"媒合單位並開始服務" }
  ]
};

