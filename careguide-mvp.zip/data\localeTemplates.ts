
import type { LocaleData } from '../types';

// TODO: This is mock data for MVP demonstration.
export const localeData: LocaleData[] = [
  {
    city: '臺北市',
    processSteps: [
      { title: '提出申請', description: '撥打1966或至各區服務中心提出申請。' },
      { title: '到府評估', description: '照管專員將與您約定時間，到家中進行訪視評估。' },
      { title: '核定計畫', description: '根據評估結果，核定您的失能等級與服務額度。' },
      { title: '啟動服務', description: '與個案管理員討論，選擇適合的服務單位並開始服務。' },
    ],
    contacts: [
      { name: '臺北市政府衛生局-長期照顧科', phone: '02-2720-8889', website: 'https://health.gov.taipei/' }
    ],
    docChecklist: ['申請人身分證', '申請人健保卡', '若有身心障礙證明請一併準備'],
    avgWaitNotes: '臺北市平均評估等候時間約為7-14個工作天，實際時間可能因案件量而異。'
  },
  {
    city: '新北市',
    processSteps: [
      { title: '提出申請', description: '可撥打1966專線、線上申請或親洽各區公所。' },
      { title: '到府評估', description: '照管專員將於5個工作日內與您聯繫並安排家訪。' },
      { title: '核定計畫', description: '評估後約7個工作天內完成計畫核定並寄發通知。' },
      { title: '啟動服務', description: '聯繫個案管理單位，共同擬定並執行照顧計畫。' },
    ],
    contacts: [
      { name: '新北市政府衛生局-長期照顧服務', phone: '02-2254-8097', website: 'https://www.health.ntpc.gov.tw/' }
    ],
    docChecklist: ['申請人身分證正反面影本', '申請人戶口名簿影本', '身心障礙證明（若有）'],
    avgWaitNotes: '新北市強調效率，致力於縮短等候時間，但偏遠地區可能稍有延遲。'
  },
  {
    city: '臺中市',
    processSteps: [
      { title: '申請', description: '透過1966專線、衛生局網站或各區衛生所申請。' },
      { title: '評估', description: '照管專員到府或在醫院進行失能等級評估。' },
      { title: '核定', description: '依評估結果核定補助額度與服務項目。' },
      { title: '服務', description: '連結A級個管單位，提供客製化照顧服務。' },
    ],
    contacts: [
      { name: '臺中市政府衛生局-長期照護科', phone: '04-2526-5394', website: 'https://www.health.taichung.gov.tw/' }
    ],
    docChecklist: ['長期照顧服務申請書', '申請人身分證', '相關身份證明文件（如身心障礙手冊）'],
    avgWaitNotes: '臺中市幅員廣大，市區與偏鄉的等候時間可能存在差異。'
  },
  {
    city: '高雄市',
    processSteps: [
      { title: '撥打1966', description: '最簡便的方式，一通電話即可啟動申請流程。' },
      { title: '專員評估', description: '長期照顧管理中心的照管專員會安排家訪。' },
      { title: '計畫核定', description: '核定個人化的照顧計畫，包含服務類型與頻率。' },
      { title: '連結服務', description: '由社區整合型服務中心(A單位)協助您連結所需服務。' },
    ],
    contacts: [
      { name: '高雄市政府衛生局-長期照護中心', phone: '07-713-1500', website: 'https://khd.kcg.gov.tw/' }
    ],
    docChecklist: ['申請人身分證', '代理人身分證（若有）', '相關福利身份證明文件'],
    avgWaitNotes: '高雄市積極佈建社區照顧資源，目標是讓市民能就近獲得服務。'
  }
];
