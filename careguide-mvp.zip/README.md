# 長照 2.0 小幫手（MVP）
前端：Vite + React + TypeScript（本地埠 3000）  
後端：Express + TypeScript（本地埠 8787）

## 功能
- 資格快篩：依輸入回傳「可能符合/不符合」與建議下一步
- 自付額試算：依等級與服務頻率估算每月自付額區間
- 縣市流程：各縣市申請流程與注意事項
- 測試 API：/api/status 顯示 ruleset 與時間

## 本機啟動
### 後端
```bash
cd server
npm install
npm run dev            # http://localhost:8787
# 或正式模式：
# npm run build && npm run start