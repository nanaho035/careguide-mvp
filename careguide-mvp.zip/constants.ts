export const RULESET_VERSION = "tw_ltc2_mvp_0.1";
export const BUILD_TIME = "2024-07-30_MVP_BUILD";
