import React from 'react';
import { RULESET_VERSION, BUILD_TIME } from '../../constants';

const faqData = [
  {
    q: '我家裡已經有請外籍家庭看護工，還可以申請長照2.0嗎？',
    a: '可以，但服務項目會有限制。您仍然可以申請「專業服務」、「交通接送」、「輔具及居家無障礙環境改善服務」以及「喘息服務」（需符合特定條件，例如外籍看護已連續工作30天）。但「居家照顧服務」和「日間照顧」等照顧服務則無法同時使用。',
  },
  {
    q: '為什麼我提出申請後，需要等待一段時間才能評估？',
    a: '提出申請後，您所在地的「長期照顧管理中心」需要安排照管專員。等候時間會因各縣市案件量、人力配置及交通距離而有所不同。一般而言，照管中心會在數個工作日內與您聯繫並約定訪視時間。若等候過久，可主動去電關心進度。',
  },
  {
    q: '如果長輩住院了，原本的長照服務會暫停嗎？',
    a: '是的，長照服務在住院期間原則上會暫停，因為住院期間的照顧應由醫院負責。出院前，您可以主動告知醫院的「出院準備小組」，請他們協助銜接出院後的長照服務，確保照顧不中斷。',
  },
  {
    q: '長照服務的費用，是全部由政府補助嗎？',
    a: '不是。長照服務採使用者「部分負擔」制度。政府會依據您的失能等級核定每月服務額度上限，並根據您的家庭經濟狀況（一般戶、中低收入戶、低收入戶）決定您需要自行負擔的比例（例如一般戶為16%）。超出額度的部分則需全額自費。',
  },
  {
    q: '什麼是「喘息服務」？誰可以申請？',
    a: '喘息服務是為了讓家庭照顧者能有臨時休息時間而設計的短期替代照顧服務。只要是實際在家中照顧失能者的家庭成員，都可以提出申請。服務方式包含讓長輩到機構住幾天（機構喘息）、到日照中心（日間照顧喘息），或安排照顧服務員到家中（居家喘息）。',
  },
  {
    q: '我住在比較偏遠的地區，交通不便怎麼辦？',
    a: '長照2.0有提供「交通接送服務」，專門協助失能者往返醫療院所、社區式服務機構（如日照中心）等地點。這項服務同樣需要部分負擔，但對於住在偏鄉或交通不便地區的民眾來說，是一項非常重要的資源。',
  },
];

const FAQPage: React.FC = () => {
  return (
    <div className="bg-white p-6 md:p-8 rounded-lg shadow-lg max-w-4xl mx-auto">
      <h2 className="text-2xl md:text-3xl font-bold text-teal-700 border-b-2 border-teal-200 pb-3 mb-6">
        常見問題 (FAQ)
      </h2>
      <div className="space-y-4">
        {faqData.map((item, index) => (
          <details key={index} className="group p-4 border rounded-lg bg-slate-50 open:bg-teal-50 transition-colors">
            <summary className="text-lg font-bold text-slate-800 cursor-pointer list-none flex justify-between items-center">
              {item.q}
              <span className="text-teal-600 transform group-open:rotate-180 transition-transform">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </span>
            </summary>
            <div className="mt-4 text-base text-slate-700 leading-relaxed">
              {item.a}
            </div>
          </details>
        ))}
      </div>
      <div className="mt-8 pt-4 border-t text-right text-xs text-slate-400">
        <p>規則版本: {RULESET_VERSION}</p>
        <p>建置時間: {BUILD_TIME}</p>
      </div>
    </div>
  );
};

export default FAQPage;
