const BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8787/api';

async function j<T>(method: 'GET' | 'POST', path: string, body?: any): Promise<T> {
  const r = await fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

export const API = {
  status: () => j<any>('GET','/status'),
  assess: (payload:{
    ageBand:'65+'|'50-64'|'<50';
    economy:'general'|'mid-low'|'low';
    hasForeignCaregiver:boolean;
    adlCount:number;
    recentHospitalization:boolean;
  }) => j<any>('POST','/assess', payload),
  copay: (payload:{
    level:'L2'|'L3'|'L4'|'L5'|'L6'|'L7'|'L8';
    economy:'general'|'mid-low'|'low';
    services:{code:'home'|'daycare'|'respite'; freqPerWeek:number}[];
  }) => j<any>('POST','/copay', payload),
};