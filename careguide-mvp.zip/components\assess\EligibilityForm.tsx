import React, { useState, useCallback } from 'react';
import type { EligibilityAnswers, EligibilityResult } from '../../types';
import { calculateEligibility } from '../../rules/eligibility';
import { RULESET_VERSION } from '../../constants';
import Disclaimer from '../common/Disclaimer';

// Define questions inside the component or import from a constants file
const questions = [
  {
    key: 'ageRange',
    prompt: '請問您的年齡是？',
    options: ['65歲以上', '55-64歲原住民', '50歲以上失智症者', '領有身心障礙證明', '以上皆非'],
  },
  {
    key: 'incomeStatus',
    prompt: '請問您的戶籍經濟狀況是？',
    options: ['一般戶', '中低收入戶', '低收入戶'],
  },
  {
    key: 'hasForeignCaregiver',
    prompt: '家中目前是否有聘僱外籍家庭看護工？',
    options: ['是', '否'],
  },
  {
    key: 'adlDifficulties',
    prompt: '在日常生活中，哪些項目「需要他人協助」？（可複選）',
    type: 'checkbox',
    options: ['洗澡', '穿脫衣物', '如廁', '移位（上下床/椅子）', '進食'],
  },
  {
    key: 'isRecentHospitalization',
    prompt: '最近三個月內是否曾因急性病症住院？',
    options: ['是', '否'],
  },
];

const EligibilityForm: React.FC = () => {
  const initialAnswers: EligibilityAnswers = {
    ageRange: '',
    incomeStatus: '',
    hasForeignCaregiver: '',
    adlDifficulties: [],
    isRecentHospitalization: '',
  };

  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<EligibilityAnswers>(initialAnswers);
  const [result, setResult] = useState<EligibilityResult | null>(null);

  const handleAnswer = (key: keyof EligibilityAnswers, value: string | string[]) => {
    setAnswers((prev) => ({ ...prev, [key]: value }));
  };
  
  const handleCheckboxAnswer = (option: string) => {
    const currentValues = answers.adlDifficulties;
    const newValues = currentValues.includes(option)
      ? currentValues.filter(item => item !== option)
      : [...currentValues, option];
    handleAnswer('adlDifficulties', newValues);
  }

  const nextStep = () => setStep((prev) => Math.min(prev + 1, questions.length));
  const prevStep = () => setStep((prev) => Math.max(prev - 1, 0));
  const restart = () => {
    setStep(0);
    setAnswers(initialAnswers);
    setResult(null);
  };

  const submitAssessment = useCallback(() => {
    const res = calculateEligibility(answers);
    setResult(res);
    // TODO: Integrate with a real analytics service
    console.log('analytics', { event: 'assessment_complete', payload: { answers, result: res } });
  }, [answers]);

  if (result) {
    return (
      <div className="bg-white p-6 md:p-8 rounded-lg shadow-lg animate-fade-in">
        <h2 className="text-2xl font-bold mb-4 text-center">快篩結果</h2>
        <div className={`p-6 rounded-md text-center ${result.eligible ? 'bg-teal-100' : 'bg-amber-100'}`}>
          <p className="text-4xl font-bold mb-2">{result.eligible ? '符合資格' : '可能不符資格'}</p>
          {result.eligible && result.levelRange && (
            <p className="text-lg text-slate-700">預估失能等級區間：<span className="font-bold">{result.levelRange}</span></p>
          )}
          <p className="text-sm text-slate-500 mt-1">此為初步預估，實際等級需由照管專員評估</p>
        </div>
        
        <div className="mt-6">
            <h3 className="font-bold text-lg mb-2">說明：</h3>
            <ul className="list-disc list-inside space-y-2 text-slate-700">
                {result.reasons.map((reason, i) => <li key={i}>{reason}</li>)}
            </ul>
        </div>

        <div className="mt-6 bg-slate-50 p-4 rounded-md">
          <h3 className="font-bold text-lg mb-2">下一步行動：</h3>
          <ul className="list-disc list-inside space-y-2 text-teal-800">
            {result.nextSteps.map((next, i) => <li key={i}>{next}</li>)}
          </ul>
        </div>

        <div className="my-6">
          <Disclaimer />
        </div>

        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <button onClick={restart} className="w-full sm:w-auto min-h-[44px] bg-teal-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-teal-700 transition-colors">
            重新評估
          </button>
        </div>
        <p className="text-right text-xs text-slate-400 mt-4">規則版本: {RULESET_VERSION}</p>
      </div>
    );
  }

  const currentQuestion = questions[step];
  
  return (
    <div className="bg-white p-6 md:p-8 rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="mb-4">
        <p className="text-sm text-slate-500">問題 {step + 1} / {questions.length}</p>
        <div className="w-full bg-slate-200 rounded-full h-2.5 mt-1">
          <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: `${((step + 1) / questions.length) * 100}%` }}></div>
        </div>
      </div>

      <h2 className="text-xl md:text-2xl font-bold mb-6 min-h-[64px]">{currentQuestion.prompt}</h2>

      <div className="space-y-3">
        {currentQuestion.type === 'checkbox' ? (
           currentQuestion.options.map((option) => (
             <label key={option} className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors duration-200 has-[:checked]:bg-teal-50 has-[:checked]:border-teal-500">
               <input
                 type="checkbox"
                 name={currentQuestion.key}
                 value={option}
                 checked={answers.adlDifficulties.includes(option)}
                 onChange={() => handleCheckboxAnswer(option)}
                 className="h-6 w-6 text-teal-600 border-slate-300 rounded focus:ring-teal-500"
               />
               <span className="ml-4 text-lg text-slate-800">{option}</span>
             </label>
           ))
        ) : (
            currentQuestion.options.map((option) => (
                <label key={option} className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors duration-200 has-[:checked]:bg-teal-50 has-[:checked]:border-teal-500">
                <input
                    type="radio"
                    name={currentQuestion.key}
                    value={option}
                    checked={answers[currentQuestion.key as keyof Omit<EligibilityAnswers, 'adlDifficulties'>] === option}
                    onChange={(e) => handleAnswer(currentQuestion.key as keyof EligibilityAnswers, e.target.value)}
                    className="h-6 w-6 text-teal-600 border-slate-300 focus:ring-teal-500"
                />
                <span className="ml-4 text-lg text-slate-800">{option}</span>
                </label>
            ))
        )}
      </div>

      <div className="mt-8 flex justify-between">
        <button
          onClick={prevStep}
          disabled={step === 0}
          className="min-h-[44px] bg-slate-300 text-slate-700 font-bold py-3 px-6 rounded-lg hover:bg-slate-400 transition-colors disabled:bg-slate-100 disabled:cursor-not-allowed"
        >
          上一題
        </button>
        {step < questions.length - 1 ? (
          <button
            onClick={nextStep}
            className="min-h-[44px] bg-teal-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-teal-700 transition-colors"
          >
            下一題
          </button>
        ) : (
          <button
            onClick={submitAssessment}
            className="min-h-[44px] bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition-colors"
          >
            看結果
          </button>
        )}
      </div>
    </div>
  );
};

export default EligibilityForm;
