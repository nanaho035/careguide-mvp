import React, { useState, useMemo } from 'react';
import type { CopayInputs, CopayResult } from '../../types';
import { calculateCopay } from '../../rules/copay';
import { RULESET_VERSION } from '../../constants';
import Disclaimer from '../common/Disclaimer';

const CopayEstimator: React.FC = () => {
    const initialInputs: CopayInputs = {
        level: 'L4',
        incomeStatus: 'general',
        services: {
            homeCareHours: 0,
            dayCareDays: 0,
            respiteDays: 0,
        },
        isRural: false,
    };

    const [inputs, setInputs] = useState<CopayInputs>(initialInputs);
    const [result, setResult] = useState<CopayResult | null>(null);
    
    const handleInputChange = (field: keyof CopayInputs, value: any) => {
        setInputs(prev => ({ ...prev, [field]: value }));
        setResult(null); // Reset result on input change
    };

    const handleServiceChange = (service: keyof CopayInputs['services'], value: number) => {
        setInputs(prev => ({
            ...prev,
            services: {
                ...prev.services,
                [service]: Math.max(0, value)
            }
        }));
        setResult(null); // Reset result on input change
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const res = calculateCopay(inputs);
        setResult(res);
        // TODO: Integrate with a real analytics service
        console.log('analytics', { event: 'copay_calculate', payload: { inputs, result: res } });
    };

    const totalBreakdownAmount = useMemo(() => {
        if (!result) return 0;
        return result.breakdown.reduce((sum, item) => sum + item.amount, 0);
    }, [result]);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <form onSubmit={handleSubmit} className="lg:col-span-2 bg-white p-6 rounded-lg shadow-lg space-y-6">
                <h2 className="text-2xl font-bold text-teal-700 border-b pb-2">自付額試算</h2>

                {/* Basic Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-lg font-bold mb-2 text-slate-700">失能等級</label>
                        <select value={inputs.level} onChange={e => handleInputChange('level', e.target.value)} className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500">
                            {['L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8'].map(l => <option key={l} value={l}>{l}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-lg font-bold mb-2 text-slate-700">戶籍經濟別</label>
                        <select value={inputs.incomeStatus} onChange={e => handleInputChange('incomeStatus', e.target.value as CopayInputs['incomeStatus'])} className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500">
                            <option value="general">一般戶</option>
                            <option value="middle_low">中低收入戶</option>
                            <option value="low">低收入戶</option>
                        </select>
                    </div>
                </div>

                {/* Service Selection */}
                <div>
                    <h3 className="text-xl font-bold mb-3 text-slate-800">選擇服務項目與頻率（每月）</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-base font-semibold text-slate-600">居家服務 (小時)</label>
                            <input type="number" value={inputs.services.homeCareHours} onChange={e => handleServiceChange('homeCareHours', parseInt(e.target.value) || 0)} className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg mt-1" placeholder="例如: 10"/>
                        </div>
                        <div>
                            <label className="block text-base font-semibold text-slate-600">日間照顧 (天)</label>
                            <input type="number" value={inputs.services.dayCareDays} onChange={e => handleServiceChange('dayCareDays', parseInt(e.target.value) || 0)} className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg mt-1" placeholder="例如: 20"/>
                        </div>
                        <div>
                            <label className="block text-base font-semibold text-slate-600">喘息服務 (天)</label>
                            <input type="number" value={inputs.services.respiteDays} onChange={e => handleServiceChange('respiteDays', parseInt(e.target.value) || 0)} className="w-full p-3 text-lg border-2 border-slate-300 rounded-lg mt-1" placeholder="例如: 4"/>
                        </div>
                    </div>
                </div>

                {/* Other Options */}
                <div>
                    <label className="flex items-center space-x-3 cursor-pointer">
                        <input type="checkbox" checked={inputs.isRural} onChange={e => handleInputChange('isRural', e.target.checked)} className="h-6 w-6 text-teal-600 border-slate-300 rounded focus:ring-teal-500"/>
                        <span className="text-lg text-slate-700">是否需要偏鄉交通接送</span>
                    </label>
                </div>
                
                <button type="submit" className="w-full min-h-[44px] bg-teal-600 text-white font-bold py-3 px-6 text-lg rounded-lg hover:bg-teal-700 transition-colors">
                    開始試算
                </button>
            </form>

            <div className="lg:col-span-1">
                <div className="bg-slate-50 p-6 rounded-lg shadow-lg sticky top-6">
                    <h3 className="text-2xl font-bold mb-4 border-b border-slate-200 pb-2 text-slate-800">試算結果</h3>
                    {result ? (
                        <div className="space-y-4 animate-fade-in">
                            <div>
                                <p className="text-lg text-slate-600">預估每月自付額</p>
                                <p className="text-4xl font-bold text-teal-700">
                                    ${result.min.toLocaleString()} ~ ${result.max.toLocaleString()}
                                </p>
                            </div>

                            {totalBreakdownAmount > 0 && (
                                <div>
                                    <p className="text-base font-bold mb-2 text-slate-600">費用結構</p>
                                    <div className="w-full bg-slate-200 rounded-lg h-8 flex overflow-hidden">
                                        {result.breakdown.map((item, index) => {
                                            if (item.amount <= 0) return null;
                                            const colors = ['bg-teal-500', 'bg-sky-500', 'bg-indigo-500', 'bg-rose-500'];
                                            const percentage = (item.amount / totalBreakdownAmount) * 100;
                                            return <div key={index} className={`${colors[index % colors.length]}`} style={{ width: `${percentage}%` }} title={`${item.service}: $${item.amount.toLocaleString()}`}></div>
                                        })}
                                    </div>
                                    <ul className="mt-3 space-y-1 text-sm text-slate-700">
                                        {result.breakdown.map((item, index) => {
                                            if (item.amount <= 0) return null;
                                            const colors = ['text-teal-600', 'text-sky-600', 'text-indigo-600', 'text-rose-600'];
                                            return <li key={index} className="flex items-center"><span className={`w-3 h-3 rounded-full mr-2 ${colors[index % colors.length].replace('text-', 'bg-')}`}></span>{item.service}: ${item.amount.toLocaleString()}</li>
                                        })}
                                    </ul>
                                </div>
                            )}

                             <div className="text-xs text-slate-500 pt-4 border-t border-slate-200">
                                <p className="font-bold mb-1">假設條件：</p>
                                <p>{inputs.level}, { {general: '一般戶', middle_low: '中低收入戶', low: '低收入戶'}[inputs.incomeStatus] }, {inputs.isRural ? '含' : '不含'}偏鄉交通費。</p>
                                <p className="mt-2 text-right">規則版本: {RULESET_VERSION}</p>
                            </div>
                            <div className="mt-4">
                                <Disclaimer />
                            </div>
                        </div>
                    ) : (
                        <div className="text-center text-slate-500 py-10">
                            <p>請在左側輸入條件，</p>
                            <p>即可開始試算您的長照費用。</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CopayEstimator;
